#!/bin/bash
# Removes the old desktop version of RunLog and RunLog Coach (the launchers and the RunLog folder),
# now that both open from the web: https://runlog-app.github.io/runlog/
# Everything goes to the Trash, so it can be put back. Your data in the new RunLog lives in your
# browser and isn't touched.
HOME_URL="https://runlog-app.github.io/runlog/"
if ! osascript -e 'display dialog "RunLog now opens from the web.\n\nBefore removing the old version, move your data: open the old RunLog once more and use \"Move my data to the new RunLog\" (then \"Bring it across\" in the new RunLog).\n\nIs your data in the new RunLog (or did you never use the old one)?" buttons {"Not yet", "Yes, remove the old version"} default button "Not yet" with title "RunLog"' 2>/dev/null | grep -q "Yes"; then
  echo "Nothing was removed. Move your data first, then run this again."
  exit 0
fi
trash() {
  [ -e "$1" ] || return
  osascript -e "tell application \"Finder\" to delete POSIX file \"$1\"" >/dev/null 2>&1 || mv "$1" "$HOME/.Trash/" 2>/dev/null
  [ -e "$1" ] && echo "Could not remove $1" || echo "Removed $1"
}
trash "$HOME/Library/Application Support/RunLog"
for d in "$HOME/Applications" "/Applications" "$HOME/Desktop" "$HOME/Downloads" "$HOME/Documents"; do
  for f in "$d/RunLog.command" "$d/RunLog Coach.command"; do trash "$f"; done
  for f in "$d"/*.htm*; do
    [ -f "$f" ] && head -c 4096 "$f" 2>/dev/null | grep -qE '<title>RunLog( Coach)?</title>' && trash "$f"
  done
done
echo "Done. The old RunLog is in the Trash."
open "$HOME_URL"
