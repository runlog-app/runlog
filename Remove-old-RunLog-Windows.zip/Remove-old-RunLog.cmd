<# : batch part of the RunLog remover, which runs the PowerShell below
@echo off
set "RL_SELF=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((Get-Content -LiteralPath $env:RL_SELF) -join [Environment]::NewLine)"
pause
exit /b
#>
# Removes the old desktop version of RunLog and RunLog Coach (the icons, the RunLog folder and
# RunLog files saved by hand), now that both open from the web: https://runlog-app.github.io/runlog/
# Everything goes to the Recycle Bin, so it can be put back. No admin rights needed.
# Your data in the new RunLog lives in your browser and isn't touched.
$ErrorActionPreference = 'Continue'
Add-Type -AssemblyName Microsoft.VisualBasic
function Recycle($path) {
  try {
    if (Test-Path -LiteralPath $path -PathType Container) {
      [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($path, 'OnlyErrorDialogs', 'SendToRecycleBin')
    } else {
      [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($path, 'OnlyErrorDialogs', 'SendToRecycleBin')
    }
    Write-Host "  Removed $path"
  } catch { Write-Host "  Could not remove $path (is it open?)" }
}

Write-Host 'RunLog now opens from the web: https://runlog-app.github.io/runlog/'
Write-Host ''
Write-Host 'Before removing the old version, move your data: click the old RunLog icon once more and use'
Write-Host '"Move my data to the new RunLog" (then "Bring it across" in the new RunLog).'
$answer = Read-Host 'Is your data in the new RunLog (or did you never use the old one)? (y/N)'
if ($answer -notmatch '^[yY]') {
  Write-Host 'Nothing was removed. Move your data first, then run this again.'
  exit
}

$Dir = Join-Path $env:LOCALAPPDATA 'RunLog'
$places = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'), (Join-Path $env:USERPROFILE 'Desktop')) | Select-Object -Unique
foreach ($place in $places) {
  foreach ($name in @('RunLog.lnk', 'RunLog Coach.lnk')) {
    $lnk = Join-Path $place $name
    if (Test-Path -LiteralPath $lnk) { Recycle $lnk }
  }
}
if (Test-Path -LiteralPath $Dir) { Recycle $Dir }

# RunLog files saved by hand (a download, a test file) on the desktop or in Downloads or Documents.
$old = @()
$looks = foreach ($folder in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:USERPROFILE 'Downloads'),
                                [Environment]::GetFolderPath('MyDocuments'), (Join-Path $env:USERPROFILE 'Desktop')) | Select-Object -Unique) {
  if ($folder -and (Test-Path $folder)) { Get-ChildItem -LiteralPath $folder -File -Filter '*.htm*' -ErrorAction SilentlyContinue }
}
foreach ($f in $looks) {
  if ($f.Length -gt 30MB -or ($f.Attributes -band 0x00400000) -or ($f.Attributes -band [IO.FileAttributes]::Offline)) { continue }
  try {
    $fs = [IO.File]::OpenRead($f.FullName); $buf = New-Object byte[] 4096; $n = $fs.Read($buf, 0, 4096); $fs.Close()
    if ([Text.Encoding]::UTF8.GetString($buf, 0, $n) -match '<title>RunLog( Coach)?</title>') { $old += $f }
  } catch { }
}
if ($old.Count -gt 0) {
  Write-Host ''
  Write-Host 'Also found RunLog files you saved yourself:'
  $old | ForEach-Object { Write-Host ('  ' + $_.FullName) }
  $a2 = Read-Host 'Remove these too? (Y/n)'
  if ($a2 -notmatch '^[nN]') { $old | ForEach-Object { Recycle $_.FullName } }
}
Write-Host ''
Write-Host 'Done. The old RunLog is in the Recycle Bin. Open the new one at https://runlog-app.github.io/runlog/'
Start-Process 'https://runlog-app.github.io/runlog/'
